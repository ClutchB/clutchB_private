# clutchB_private
## about cit 82
Red means committed/ green means new changes have been made.
### Career paths to certification or associates in web development.
-spoke about  HTML, CSS:core conceptfor web development, Bootstrap: makes for responsive web pages, also Java script programming language will be covered at a later date.
Late work will be accepted with a 255 deduction.
Preffered ethod of contact will be through canvas email; will try to grade daily if work is submitted 24hrs prior to due date it can be corrected and resubmited.
VSCode: free editor form microsoft works on most major operating systems.
LS= list of files
pwd= what directory am i in?
Difference between GUI and command line.
