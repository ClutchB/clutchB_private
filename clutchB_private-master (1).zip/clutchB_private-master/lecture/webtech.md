# Introductions (Week 1)
- the Web vs Internet: the Interne refers to a massive network of computers while the Web refersto a way of transmitting data via various protocols. Alsothe different types of servers, various transmission protocols etc.
-Client/Server: searchterm->DNS Server->WebServer->backto user-Java script also executed.
-DNS: site name->translates to ip address->
-Protocols: Application Layer->Link Layer->Transport Layer->Internet Layer.
-HTTP: Web protocol used to transfer data across the web.stateless Protocol, headers, appication layer, client server. 
-Anatomy of URL: Protocol->Resource name->Subdomain->Domain->Top level Domain
-Browsers: Browser->Internal Engine->Rendering Engine->Networking->Data Storage->Java Script Interpreter.
-Web Standards & W3C: Browser Wars, Web standards, 1994 standardized web,2013 workis done onweb standards, w3.org.
-Web Servers: shared hosting vs dedicated hosting, web stack, each serverhas its own dedicated stack, LAMP most popular. Cold fusion, make sure that whatever you use gsupports your stuff.
## Front End Technology (Wek 1)
UI technology, clientside and server sid, HTML AND Javascript,mockups, accesability, Images and Icon Assets.
HTML language ofthe web: very simple and essential, standard, 3.0 release created a lot of problems, 4.0 stabilized the languageand became the recognized language, xhtml,xhtml 2.0 structural language only, 2009 xhtml was disbanded, html5 backwards compatable and more user friendly and easy to learn.
Structure HTML: Tags, syntax,elements and basic structure. Open and closing tag->head tag->
CSS: Selector and declarartion, property:value,mdular design.
Java Script: develope 1995 by netscape, nothing to do with Java, interactive elements, in the browser or client side.
Common Image Types:JPEG,PNG,GIF,SVG, File size and quality aways a concern, JPEG not recomended to save files they are compressed everytime they are save. PNG losslesscompresion format, larger file size, not totally backwards compatible, SVG: any size or any color best of all the file types, most mdern browsers support.
API: SET OF INSTRUCTIONS AND STANDARDS, leverage the larger applications that allows the web to grow, compelling content and really powerfull features. 
HTML 5 API: intergration of the application capabilities into HTML itself, WHATWG, Media API, drag and drop API, app cache API,Geolocation API, very important to developing complex sites.
Web Fonts: @font-face technique, end user license agreements, EOT, WOFF, 
 ### Back-End Technology (Week 2)
 8. Server side scripting or CGI (common gateway interfaces).
 6.Client side scripting can better controlled with Java Scripting.
 7. php 3.0 (hypertext preprocessor) pairing with apache etc.
 5. PHP code invisible.
 1. PHP is on almostallhosting plans.
 1. Large pool of developers to work with.
 1.PHP is easy to learn and has lotsofresources todraw from.
 1. JSP code is used for almost anything and ported to almost any server environment.

2. Make sure you choose the proper Java platform.
 2. .NET: Visual Basics.
 2. Often used for large sacle, enterprise szed sites.
 2. Can only be hosted on windows server so it might be limited.
 
 #coldfusion
 - Uses mark up language like HTML.
 - Central administration makes many tasks easier.
 - require less code than other languages.
 - Harder to find hosts and more expensive than other choices. 
 - Due to more hosting prices havee dropped.
  
  #Python
 - Powerful develpment language.
 - variety of libraries makes it easier to build sites andd web- based applications.
 - Use to create large sites or applications 
 - Ruby on rails exploded simple syntax and powerful capabilities.
 
 1. Dealind with Data
 - Stored locally on client or simplyin text files called cookis.
 - Key value pairs
 - Json (Java Script Oblect Notation)
 - Database.
 - Scripting used to displayinfo like aspreadsheet.
 -Relational and Non- relational.
 -
 
 
 
 
 
 
 
 
 
 
 
 
 
 
